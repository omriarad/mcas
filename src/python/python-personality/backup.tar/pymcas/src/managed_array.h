#ifndef __MANAGED_ARRAY_TYPE_H__
#define __MANAGED_ARRAY_TYPE_H__

#define NPY_NO_DEPRECATED_API NPY_1_7_API_VERSION

#include <numpy/ndarraytypes.h>

#include <api/mcas_itf.h>
#include <api/kvstore_itf.h>

typedef struct {
  PyObject_HEAD
  PyObject * _array; /* base class instance */
  void *    _data;
  int       _data_len;
  component::IMCAS *          _mcas;
  component::IKVStore::pool_t _pool;
} ManagedArray;

ManagedArray * ManagedArray_new();

extern PyTypeObject ManagedArrayType;

#define PyManagedArray_Check(op) PyObject_TypeCheck(op, &ManagedArrayType)

#endif

