#define NPY_NO_DEPRECATED_API NPY_1_7_API_VERSION
#define NO_IMPORT_ARRAY
#define PY_ARRAY_UNIQUE_SYMBOL pymcascore_ARRAY_API



#include "managed_array.h"

#include <string_view>
#include <common/logging.h>
#include <common/dump_utils.h>
#include <common/utils.h>
#include <Python.h>
#include <structmember.h>

#include <numpy/arrayobject.h>

namespace global
{
extern unsigned debug_level;
}


extern PyTypeObject ManagedArrayType;

static int
ManagedArray_init(ManagedArray *self, PyObject *args, PyObject *kwds)
{
  if (PyArray_Type.tp_init((PyObject *) self, args, kwds) < 0)
    return -1;

  //self->state = 0;
  return 0;
}

static PyObject *
ManagedArray_new(PyTypeObject *type, PyObject *args, PyObject *kwargs)
{
  PNOTICE("ManagedArray_new (%p) with args", type);
  auto self = (ManagedArray *)type->tp_alloc(type, 0);
  assert(self);

  static const char *kwlist[] = {"data",
                                 "header_length",
                                 NULL};

  PyObject * bytes_memory_view  = nullptr;
  Py_ssize_t header_length = 0;

  if (! PyArg_ParseTupleAndKeywords(args,
                                    kwargs,
                                    "On",
                                    const_cast<char**>(kwlist),
                                    &bytes_memory_view,
                                    &header_length)) {
    PyErr_SetString(PyExc_RuntimeError,"bad arguments!");
    return NULL;
  }

  if (! PyMemoryView_Check(bytes_memory_view)) {
    PyErr_SetString(PyExc_RuntimeError,"data should be type <memoryview>");
    return NULL;
  }
  
  PNOTICE("header_length = %lu", header_length);
  Py_INCREF(bytes_memory_view); /* increment reference count to hold data */

  Py_buffer * buffer = PyMemoryView_GET_BUFFER(bytes_memory_view);
  byte * ptr = (byte *) buffer->buf;

  if(global::debug_level > 1)
    hexdump(ptr, header_length);
  
  int ndims = *(reinterpret_cast<npy_intp*>(ptr));
  ptr += sizeof(ndims);

  std::vector<npy_intp> dims;
  for(int i=0; i < ndims; i++) {
    npy_intp dim = *(reinterpret_cast<npy_intp*>(ptr));
    ptr += sizeof(dim);
    dims.push_back(dim);
  }

  std::vector<npy_intp> strides;
  for(int i=0; i < ndims; i++) {
    npy_intp stride = *(reinterpret_cast<npy_intp*>(ptr));
    ptr += sizeof(stride);
    strides.push_back(stride);
  }

  int flags = *(reinterpret_cast<int*>(ptr));
  ptr += sizeof(flags);
  
  int dtype =  *(reinterpret_cast<int*>(ptr));
  ptr += sizeof(dtype);
  
  PNOTICE("ndims=%d, flags=%d, dtype=%d", ndims, flags, dtype);
  for(auto d: dims) PNOTICE("dim=%ld", d);
  for(auto s: strides) PNOTICE("stride=%ld", s);
  PNOTICE("buffer=%p", buffer->buf);

  PyObject* nparray = PyArray_New(&PyArray_Type,
                                  ndims,
                                  dims.data(),
                                  dtype,
                                  strides.data(),
                                  ptr, // TO DO check with header length?
                                  1, // TO FIX
                                  flags,
                                  NULL);
  self->_array = nparray;

  return (PyObject*) self;
}

ManagedArray * ManagedArray_new()
{
  auto value = (ManagedArray *) PyType_GenericAlloc(&ManagedArrayType,1);
  PNOTICE("ManagedArray_new (%p)", value);
  return value;
}

/** 
 * tp_dealloc: Called when reference count is 0
 * 
 * @param self 
 */
static void
ManagedArray_dealloc(ManagedArray *self)
{
  assert(self);
  //  assert(self->_mcas);
  //  assert(self->_pool);
  PNOTICE("ManagedArray_dealloc (%p)", self);
  
  /* implicitly close pool */
  //  self->_mcas->close_pool(self->_pool);
  //  self->_mcas->release_ref();
  
  Py_TYPE(self)->tp_free((PyObject*)self);
}

static PyMemberDef ManagedArray_members[] = {
  {NULL}
};



static PyMethodDef ManagedArray_methods[] = {
  {NULL}
};



PyTypeObject ManagedArrayType = {
  PyVarObject_HEAD_INIT(NULL, 0)
  "pymcas.pymcascore.ManagedArray",           /* tp_name */
  sizeof(ManagedArray)   ,      /* tp_basicsize */
  0,                       /* tp_itemsize */
  (destructor) ManagedArray_dealloc,      /* tp_dealloc */
  0,                       /* tp_print */
  0,                       /* tp_getattr */
  0,                       /* tp_setattr */
  0,                       /* tp_reserved */
  0,                       /* tp_repr */
  0,                       /* tp_as_number */
  0,                       /* tp_as_sequence */
  0,                       /* tp_as_mapping */
  0,                       /* tp_hash */
  0,                       /* tp_call */
  0,                       /* tp_str */
  0,                       /* tp_getattro */
  0,                       /* tp_setattro */
  0,                       /* tp_as_buffer */
  Py_TPFLAGS_DEFAULT | Py_TPFLAGS_BASETYPE, /* tp_flags */
  "ManagedArray",              /* tp_doc */
  0,                       /* tp_traverse */
  0,                       /* tp_clear */
  0,                       /* tp_richcompare */
  0,                       /* tp_weaklistoffset */
  0,                       /* tp_iter */
  0,                       /* tp_iternext */
  ManagedArray_methods,         /* tp_methods */
  ManagedArray_members,         /* tp_members */
  0,                       /* tp_getset */
  0,                       /* tp_base */
  0,                       /* tp_dict */
  0,                       /* tp_descr_get */
  0,                       /* tp_descr_set */
  0,                       /* tp_dictoffset */
  0, //(initproc) ManagedArray_init,  /* tp_init */
  0,            /* tp_alloc */
  ManagedArray_new,             /* tp_new */
  0, /* tp_free */
};

  


