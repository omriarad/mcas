# Copyright [2017-2021] [IBM Corporation]
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# See the License for the specific language governing permissions and
# limitations under the License.

# api.py

#from mcas import *
import mcas
import pymcascore
import pymcas
import flatbuffers
import sys
import numpy as np

from flatbuffers import util

# protocol API
from pymcas.Proto.Element import *
from pymcas.Proto.DataType import *
from pymcas.Proto.DataDescriptor import *
from pymcas.Proto.CodeType import *
from pymcas.Proto.InvokeReply import *
from pymcas.Proto.InvokeRequest import *
from pymcas.Proto.Operation import *
from pymcas.Proto.Message import *

# decorator function to type and range check parameters
def paramcheck(types, ranges=None):
    def __f(f):
        def _f(*args, **kwargs):
            for a, t in zip(args, types):
                if not isinstance(a, t):
                    raise TypeError("expected type %s got %r" % (t, a))
            for a, r in zip(args, ranges or []):
                if r and not r[0] <= a <= r[1]:
                    raise ValueError("expected value in range %r: %r" % (r, a))
            return f(*args, **kwargs)
        return _f
    return __f


def methodcheck(types, ranges=None):
    def __f(f):
        def _f(*args, **kwargs):
            for a, t in zip(args[1:], types):
                if not isinstance(a, t):
                    raise TypeError("method expected type %s got %r" % (t, a))
            for a, r in zip(args[1:], ranges or []):
                if r and not r[0] <= a <= r[1]:
                    raise ValueError("method expected value in range %r: %r" % (r, a))
            return f(*args, **kwargs)
        return _f
    return __f


@paramcheck(types=[str,int,str,str,int], ranges=[None, None, None, None, None])
def create_session(ip, port, device="mlx5_0", extra="", debug=0):
    return Session(ip, port, device, extra, debug)


class Session():
    """
    Session class represents connection to MCAS server
    """       
    __session = None

    @methodcheck(types=[str, int, str, str, int], ranges=[None, None, None, None, None])
    def __init__(self, ip, port, device="mlx5_0", extra="", debug=0):
        self.__session = mcas.Session(ip, port, device, extra, debug)

    @methodcheck(types=[str, int, int, bool])
    def create_pool(self, name, size=32000000, count=1000, create_only=False):
        return Pool(self.__session.create_pool(name, size, count, create_only))

    
class ManagedArray():
    """
    Managed array
    """
    def __init__(self, arr, raw_memory_view, pool):
        self.array = arr
        self.raw = raw_memory_view
        self.pool = pool
        
    def __array__(self):
        return self.array
    

#         #        Super(ManagedNumpyArray, self).__init__(value=20)        
#     # def __init__(self, shape, dtype=float, buffer=None, offset=0, strides=None, order=None):
#     #     print("New Managed ndarray")
        

class Pool():
    """
    Pool class
    """
    @methodcheck(types=[mcas.Pool])
    def __init__(self, pool):
        self.__pool = pool

    @methodcheck(types=[str])
    def save(self, key, value):
        """Save Python object to MCAS pool"""
        if isinstance(value, np.ndarray):

            #
            # [ fb metadata | numpy hdr | numpy data ]
            #
            
            # create opaque header (byte array)
            hdr = pymcascore.ndarray_header(value)
            
            builder = flatbuffers.Builder(256) # initial size
            key_fb = builder.CreateString(key)

            DataDescriptorStart(builder)
            DataDescriptorAddGlobalName(builder, key_fb)
            DataDescriptorAddType(builder, DataType().NumPyArray)
            DataDescriptorAddHeaderLength(builder, len(hdr))
            DataDescriptorAddDataLength(builder, len(value))
            dd = DataDescriptorEnd(builder)

            MessageStart(builder)
            MessageAddElementType(builder, Element.DataDescriptor)
            MessageAddElement(builder, dd)
            msg = MessageEnd(builder)
            
            builder.FinishSizePrefixed(msg)

            # until we have scatter put, we need a contiguous byte array
            # or memoryview

            # construct message
            data = builder.Output()      # flatbuffer info
            data.extend(hdr)             # ndarray header
            data.extend(value.tobytes()) # ndarray actual data

            print('save: total len = {0}'.format(len(data)))
            self.__pool.put_direct(key, data) # not sure this works without special memory?

    def load(self, key):
        """
        Load Python object from MCAS pool
        """
        # using get_direct will get size first, allocate memory
        # and then issue get.  Return type is <memoryview>
        raw_obj = self.__pool.get_direct(key)

        print("load: length of {0} is {1}".format(key, len(raw_obj)))

        # extract 4 byte size prefix
        msg_size = util.GetSizePrefix(raw_obj, 0)
        print("msg_size:", msg_size)

        # parse Message
        root = pymcas.Proto.Message.Message()
        msg = root.GetRootAsMessage(raw_obj[4:], 0) # size prefix is 4 bytes
        print("version : {0}".format(int(msg.Version())))

        # check magic
        if (msg.Magic() != 0xc0ffee0):
            raise ValueError("bad magic")

        if (msg.ElementType() != Element.DataDescriptor):
            raise ValueError("bad packet format")
            
        dd = pymcas.Proto.DataDescriptor.DataDescriptor()
        dd.Init(msg.Element().Bytes, msg.Element().Pos)

        # handle NumPyArray data type
        global_name = dd.GlobalName()
        print("element - name={0}, hdrlen={1} datalen={2}".format(global_name, dd.HeaderLength(), dd.DataLength()))
        if dd.Type() == DataType.NumPyArray:
            ndarray_data = raw_obj[msg_size:]
            print("ndarray_data: len={0} {1}".format(len(ndarray_data),type(ndarray_data)))
            arr = pymcascore.ndarray_from_bytes(raw_obj[msg_size+4:], # zero-copy slice, add 4 for prefix
                                                dd.HeaderLength()) #, dd.DataLength())
            
            return ManagedArray(arr, raw_obj, self.__pool)
        
        
        


def test_0():
    session = pymcas.create_session("10.0.0.101", 11911, debug=3)
    if sys.getrefcount(session) != 2:
        raise ValueError("session ref count should be 2")
    pool = session.create_pool("myPool")
    if sys.getrefcount(pool) != 2:
        raise ValueError("pool ref count should be 2")

    a = np.identity(10)
    print(a)
    key = 'object-A'
    pool.save(key, a)

    b = pool.load(key)
    print("test0 OK!?")
    print("result of load:")
    print(b)
    return b



def test_ref_cnt():
    session = mcas.Session("10.0.0.101", 11911)
    pool = session.create_pool('fooPool', 100)
    session = 0
    pool = 0
    

def bye():
    print("bye!")

def hello():
    print("hello")
